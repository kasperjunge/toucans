class Prompt:
    def __init__(self):
        pass

    def __repr__(self):
        return "Prompt Object"


class ChatFlow:
    def __init__(self):
        pass

    def __repr__(self):
        return "ChatFlow Object"
